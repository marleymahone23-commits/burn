const { EmbedBuilder } = require('discord.js');
const axios = require('axios');

// OpenAI API Configuration
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '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';

// Cooldown system to prevent spam (userId -> lastRequestTime)
const userCooldowns = new Map();
const COOLDOWN_TIME = 5000; // 5 seconds between requests per user

module.exports = {
  name: 'chatgpt',
  aliases: ['ai'],
  category: 'ai',
  description: '<:arrows:1363099226375979058> Generate text using OpenAI (ChatGPT).',
  async execute(message, args, { prefix }) {
    if (!OPENAI_API_KEY || OPENAI_API_KEY === '') {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#FF4D4D')
            .setDescription([
              '<:excl:1362858572677120252> <:arrows:1363099226375979058> **API not configured.**',
              '',
              '-# OpenAI API key is not set. Please configure `OPENAI_API_KEY` in your environment variables.',
              '',
              'Get your API key from: https://platform.openai.com/api-keys'
            ].join('\n'))
        ]
      });
    }

    const prompt = args.join(' ').trim();

    if (!prompt || prompt.length === 0) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#838996')
            .setDescription([
              '<:excl:1362858572677120252> <:arrows:1363099226375979058> **Invalid usage.**',
              '',
              '**Usage:**',
              `\`${prefix}generate [prompt]\``,
              `\`${prefix}ai [prompt]\``,
              `\`${prefix}chatgpt [prompt]\``,
              '',
              '**Examples:**',
              `\`${prefix}generate Write a short story about a robot\``,
              `\`${prefix}ai Explain quantum computing in simple terms\``,
              `\`${prefix}chatgpt What is the capital of France?\``,
              '',
              '-# Provide a prompt to generate AI text.'
            ].join('\n'))
        ]
      });
    }

    if (prompt.length > 2000) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#838996')
            .setDescription([
              '<:excl:1362858572677120252> <:arrows:1363099226375979058> **Prompt too long.**',
              '',
              '-# Please keep your prompt under 2000 characters.'
            ].join('\n'))
        ]
      });
    }

    // Check cooldown
    const userId = message.author.id;
    const lastRequest = userCooldowns.get(userId);
    const now = Date.now();
    
    if (lastRequest && (now - lastRequest) < COOLDOWN_TIME) {
      const remaining = Math.ceil((COOLDOWN_TIME - (now - lastRequest)) / 1000);
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#838996')
            .setDescription([
              '<:excl:1362858572677120252> <:arrows:1363099226375979058> **Please wait.**',
              '',
              `-# You can use this command again in **${remaining} seconds**.`
            ].join('\n'))
        ]
      });
    }

    // Update cooldown
    userCooldowns.set(userId, now);

    try {
      // Show processing message
      const processingMsg = await message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#838996')
            .setDescription('<:arrows:1363099226375979058> Generating response... This may take a few seconds.')
        ]
      });

      // Call OpenAI API with retry logic for rate limits
      let apiResponse;
      let retries = 0;
      const maxRetries = 2;
      
      while (retries <= maxRetries) {
        try {
          apiResponse = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
              model: 'gpt-3.5-turbo',
              messages: [
                {
                  role: 'user',
                  content: prompt
                }
              ],
              max_tokens: 1000,
              temperature: 0.7
            },
            {
              headers: {
                'Authorization': `Bearer ${OPENAI_API_KEY}`,
                'Content-Type': 'application/json'
              },
              timeout: 60000
            }
          );
          
          // Success, break out of retry loop
          break;
          
        } catch (err) {
          // Handle rate limits with retry
          if (err.response?.status === 429 && retries < maxRetries) {
            const retryAfter = err.response.headers['retry-after'] || 2;
            const waitTime = parseInt(retryAfter) * 1000;
            
            // Update processing message
            await processingMsg.edit({
              embeds: [
                new EmbedBuilder()
                  .setColor('#838996')
                  .setDescription(`<:arrows:1363099226375979058> Rate limited. Retrying in ${retryAfter} seconds... (Attempt ${retries + 1}/${maxRetries + 1})`)
              ]
            });
            
            // Wait before retrying
            await new Promise(resolve => setTimeout(resolve, waitTime));
            retries++;
            continue;
          }
          
          // Handle other errors
          if (err.response) {
            const errorData = err.response.data;
            const status = err.response.status;
            let errorMsg = errorData?.error?.message || errorData?.message || err.response.statusText;
            
            if (status === 401) {
              errorMsg = 'Invalid API key. Please check your OpenAI API key configuration.';
            } else if (status === 429) {
              const retryAfter = err.response.headers['retry-after'];
              errorMsg = retryAfter 
                ? `Rate limit exceeded. Please try again in ${retryAfter} seconds.`
                : 'Rate limit exceeded. Please wait a moment and try again.';
            } else if (status === 500 || status === 503) {
              errorMsg = 'OpenAI service is temporarily unavailable. Please try again later.';
            } else if (status === 402 || errorMsg.includes('insufficient_quota')) {
              errorMsg = 'Insufficient quota. Please check your OpenAI account billing and credits.';
            }
            
            throw new Error(errorMsg);
          }
          
          // Network or other errors
          throw new Error(`API request failed: ${err.message}`);
        }
      }
      
      if (!apiResponse) {
        throw new Error('Failed to get response from OpenAI API after retries');
      }

      const result = apiResponse.data;
      const generatedText = result.choices?.[0]?.message?.content;

      if (!generatedText) {
        throw new Error('No response generated from API');
      }

      // Discord has a 4096 character limit for embed descriptions
      const displayText = generatedText.length > 4000 
        ? generatedText.substring(0, 4000) + '...\n\n*(Response truncated)*'
        : generatedText;

      // Update with results
      await processingMsg.edit({
        embeds: [
          new EmbedBuilder()
            .setColor('#57F287')
            .setTitle('🤖 AI Generated Response')
            .setDescription(displayText)
            .addFields(
              {
                name: 'Prompt',
                value: prompt.length > 1024 ? prompt.substring(0, 1024) + '...' : prompt,
                inline: false
              }
            )
            .setFooter({ 
              text: `Model: ${result.model || 'gpt-3.5-turbo'} • Tokens: ${result.usage?.total_tokens || 'N/A'}` 
            })
            .setTimestamp()
        ]
      });

      // If response is too long, send the full text in a follow-up message
      if (generatedText.length > 4000) {
        const chunks = [];
        for (let i = 0; i < generatedText.length; i += 2000) {
          chunks.push(generatedText.substring(i, i + 2000));
        }
        
        for (const chunk of chunks) {
          await message.channel.send({
            embeds: [
              new EmbedBuilder()
                .setColor('#838996')
                .setDescription(chunk)
            ]
          });
        }
      }

    } catch (error) {
      console.error('OpenAI API error:', error);
      
      let errorMessage = error.message;
      
      // Error message is already formatted from the catch block above

      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#FF4D4D')
            .setDescription([
              '<:excl:1362858572677120252> <:arrows:1363099226375979058> **Error generating response.**',
              '',
              `**Error:** ${errorMessage}`,
              '',
              '-# Please try again later or check your API configuration.'
            ].join('\n'))
        ]
      });
    }
  }
};

